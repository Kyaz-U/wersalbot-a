# AI prediction logic placeholder

def predict(game, data):
    return 'safe'