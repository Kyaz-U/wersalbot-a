# WersalBot
Telegram AI Signal Bot for games like Aviator, Crash, LuckyJet, Mines, Dice, Hilo.